// get vars
var url = window.location.href;
var urlobj = new URL(url);
var metadesc = getMeta('description');
var title = document.title;
var referrer = document.referrer;
var oldHref = document.location.href;
// url update twitter search
window.onload = function() {
    var bodyList = document.querySelector("body")
    var observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (oldHref != document.location.href) {
               oldHref = document.location.href;
               url = window.location.href;
               urlobj = new URL(url);
               title = document.title;
               getData();
            }
        });
    });
    var config = {
        childList: true,
        subtree: true
    };
    observer.observe(bodyList, config);
};
var ad5bid = '5bsadext';
var cansh = 0;
var stop5bad = 0;
chrome.storage.local.get(['bs_key', 'cansh', 'stop5bad'], function(result) {
   ad5bid = result.bs_key;
   if (result.cansh==null || result.cansh=="") {
      cansh = 0;
   } else {
      cansh = result.cansh;
   }
   if (result.stop5bad==null || result.stop5bad=="") {
      stop5bad = 0;
   } else {
      stop5bad = result.stop5bad;
   }
});
// methods
function get5Bad() {
   if (stop5bad==1) {
      return;
   }
   if(chrome.runtime.id == undefined) {
      return;
   }
   chrome.runtime.sendMessage({msg: "get5Bad", w:window.screen.width, h:window.screen.height, s:0}, function(response) {
      show5bsad(response);
   });
}
function sendTracker(s) {
   chrome.runtime.sendMessage({msg: "send2Server", w:window.screen.width, h:window.screen.height, s:s}, function(response) {
      show5bsad(response);
   });
}
function show5bsad(response) {
   if (document.contains(document.getElementById(ad5bid))) {
      document.getElementById(ad5bid).remove();
   }
   let banner= document.createElement("div");
   banner.id = ad5bid;
   banner.innerHTML = response;
   document.body.append(banner);
   //setTimeout(() => {get5Bad();}, 60000);
}
function getMeta(metaName) {
   const metas = document.getElementsByTagName('meta');
   for (let i = 0; i < metas.length; i++) {
      if (metas[i].getAttribute('name') === metaName) {
      return metas[i].getAttribute('content');
      }
   }
   return '';
}
function storePages() {
   chrome.storage.local.get({'bs_pages': []}, function (result) {
      var bs_pages = result.bs_pages;
      bs_pages.push({url: urlobj.pathname});
      chrome.storage.local.set({bs_pages: bs_pages, bs_pagehost: urlobj.host}, function () {return true;});
   });
}
function storeLastHost(host) {
   chrome.storage.local.set({bs_last_host: host}, function() {
   });
}
function getData() {
   // get last host
   chrome.storage.local.get(['bs_last_host'], function(result) {
      var last_host = result.bs_last_host;
      storeLastHost(urlobj.host);
      let p = urlobj.pathname;
      // detect facebook or twitter search
      if (urlobj.host.includes('facebook.') || urlobj.host.includes('twitter.') || urlobj.host.includes('etsy.com') 
         || urlobj.host.includes('reddit.') || urlobj.host.includes('tiktok.')) {
         // mobile fb
         if (p.startsWith("/graphsearch/str/")) {
            let kw = urlobj.pathname.replace('/graphsearch/str/', '');
            kw = kw.replace('/keywords_search', '');
            kw = kw.replace('+',' ');
            chrome.storage.local.set({bs_protocol: urlobj.protocol, bs_kw:kw, bs_se:urlobj.host, bs_host:urlobj.host}, function() {
               sendTracker(1);
               return;
            });
            storePages();
            return;
         }
         if (p=="/search" || p=="/search/" || p=="/search/top" || p=="/search/user" || p=="/s") {
            const urlParams = new URLSearchParams(window.location.search);
            let bs_kw = urlParams.get('q');
            bs_kw = bs_kw.replace('#', '');
            chrome.storage.local.set({bs_protocol: urlobj.protocol, bs_kw:bs_kw, bs_se:urlobj.host, bs_host:urlobj.host}, function() {
               sendTracker(1);
               return;
            });
            return;
         }
         storePages();
         get5Bad();
         return;
      }
      // amazon
      if (urlobj.host.includes('amazon.')) {
         if (p=="/s") {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('k')) {
               let bs_kw = urlParams.get('k');
               chrome.storage.local.set({bs_protocol: urlobj.protocol, bs_kw:bs_kw, bs_se:urlobj.host, bs_host:urlobj.host}, function() {
                  sendTracker(1);
                  return;
               });
               return;
            }
            return;
         }
         storePages();
         get5Bad();
         return;
      }
      // alibaba
      if (urlobj.host.includes('alibaba.')) {
         if (p=="/trade/search") {
            const urlParams = new URLSearchParams(window.location.search);
            let bs_kw = urlParams.get('SearchText');
            chrome.storage.local.set({bs_protocol: urlobj.protocol, bs_kw:bs_kw, bs_se:urlobj.host, bs_host:urlobj.host}, function() {
               sendTracker(1);
               return;
            });
            return;
         }
         storePages();
         get5Bad();
         return;
      }
      // ebay
      if (urlobj.host.includes('ebay.')) {
         if (p=="/sch/i.html") {
            const urlParams = new URLSearchParams(window.location.search);
            let bs_kw = urlParams.get('_nkw');
            chrome.storage.local.set({bs_protocol: urlobj.protocol, bs_kw:bs_kw, bs_se:urlobj.host, bs_host:urlobj.host}, function() {
               sendTracker(1);
               return;
            });
            return;
         }
         storePages();
         get5Bad();
         return;
      }
      // linkedin
      if (urlobj.host.includes('linkedin.')) {
         if (p=="/search/results/all/") {
            const urlParams = new URLSearchParams(window.location.search);
            let bs_kw = urlParams.get('keywords');
            chrome.storage.local.set({bs_protocol: urlobj.protocol, bs_kw:bs_kw, bs_se:urlobj.host, bs_host:urlobj.host}, function() {
               sendTracker(1);
               return;
            });
            return;
         }
         storePages();
         get5Bad();
         return;
      }
      // detect youtube search
      if (urlobj.host.includes('youtube.')) {
         if (p=="/results") {
            const urlParams = new URLSearchParams(window.location.search);
            let bs_kw = urlParams.get('search_query');
            chrome.storage.local.set({bs_protocol: urlobj.protocol, bs_kw:bs_kw, bs_se:urlobj.host, bs_host:urlobj.host}, function() {
               sendTracker(1);
               return;
            });
            return;
         }
         storePages();
         get5Bad();
         return;
      }
      // detect yahoo search
      if (urlobj.host.includes('yahoo.')) {
         if (p.startsWith("/search")) {
            const urlParams = new URLSearchParams(window.location.search);
            let bs_kw = urlParams.get('p');
            chrome.storage.local.set({bs_protocol: urlobj.protocol, bs_kw:bs_kw, bs_se:urlobj.host, bs_host:urlobj.host}, function() {
               sendTracker(1);
               return;
            });
            return;
         }
         storePages();
         get5Bad();
         return;
      }
      // if user has searched - store keywords
      if (urlobj.host.includes('google.') || urlobj.host.includes('bing.') || urlobj.host.includes('yandex.') || urlobj.host.includes('duckduckgo.')) {
         if (p=="/search" || p=="/search/" || p=="/") {
            const urlParams = new URLSearchParams(window.location.search);
            let qp = 'q';
            if (urlobj.host.includes('yandex.')) {
               qp = 'text';
            }
            const bs_kw = urlParams.get(qp);
            if (bs_kw!="" && bs_kw!=null) {
               chrome.storage.local.set({bs_protocol: urlobj.protocol, bs_kw:bs_kw, bs_se:urlobj.host, bs_host:urlobj.host}, function() {
                  sendTracker(1);
                  return;
               });
               chrome.storage.local.set({bs_kw:bs_kw, bs_protocol: urlobj.protocol, bs_se:urlobj.host}, function() {
               });
               return;
            }
         }
         // new search
         if (last_host && last_host!=="undefined" && !last_host.includes('google.') && !last_host.includes('bing.') && !last_host.includes('yandex.') && !last_host.includes('duckduckgo.')) {
            sendTracker(0);
            return;
         }
         //get5Bad();
         // end
      } else {
         // landed from search
         if ((last_host && last_host!=="undefined") && (last_host.includes('google.') || last_host.includes('bing.') || last_host.includes('yandex.') || last_host.includes('duckduckgo.'))) {
            let vars  = {bs_protocol: urlobj.protocol, bs_host:urlobj.host, bs_pathname:urlobj.pathname, title:title, metadesc:metadesc};
            chrome.storage.local.set(vars, function() {
               sendTracker(0);
               return;
            });
            return;
         }
         if ((last_host && last_host!=="undefined") && (last_host!=urlobj.host)) {
            let vars  = {bs_protocol: urlobj.protocol, bs_host:urlobj.host, bs_pathname:urlobj.pathname, title:title, metadesc:metadesc};
            chrome.storage.local.set(vars, function() {
               sendTracker(0);
               return;
            });
            return;
         }
         storePages();
         if(cansh==1) {
            get5Bad();
         }
      }
   });
}
getData();