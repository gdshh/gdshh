var api_url = 'https://5billionsales.us/';
var web_url = 'https://5billionsales.com/';
// methods
function send2Server() {
   chrome.storage.local.get(['bs_kw', 'bs_se', 'bs_pages', 'bs_last_host', 'bs_protocol', 'bs_host', 'bs_pathname', 'title', 'metadesc', 'bs_id', 'bs_key', 'version'], function(result) {
      let params = {
         kw: result.bs_kw,
         se: result.bs_se,
         pages: result.bs_pages,
         last_host: result.bs_last_host,
         protocol: result.bs_protocol,
         host: result.bs_host,
         pathname: result.bs_pathname,
         title: result.title,
         metadesc: result.metadesc,
         uid: result.bs_id,
         ukey: result.bs_key,
         v: result.version
      };
      if ((result.bs_se==null)||(result.bs_se=="")) {

      } else {
         postData(api_url+'api/tracker', params)
         .then(data => {
            if (data.hasOwnProperty('action')) {
               if (data.action=="notify") {
                  var noticon = chrome.runtime.getURL("icon_48.png");
                  chrome.notifications.create('5bs', {
                     type: "basic",
                     title: data.title,
                     message: data.pop,
                     buttons: [{title:data.btn}],
                     iconUrl: noticon
                  });
                  chrome.notifications.onButtonClicked.addListener((id, index) => {
                     chrome.notifications.clear(id);
                     chrome.tabs.create({
                        url: data.url
                     });
                  });
               }
            }
         });
      }
      chrome.storage.local.remove(['bs_kw', 'bs_se', 'bs_pages', 'bs_protocol', 'bs_host', 'bs_pathname', 'title', 'metadesc'],function() {return true;});
   });
}
function setUser(json) {
   chrome.storage.local.set({bs_id:json.u, bs_key:json.k, version:json.version}, function() {
      sendInstallDetails(json);
   });
   var exiturl = web_url+'extension/uninstall/'+json.u+'/'+json.k;
   chrome.runtime.setUninstallURL(exiturl);
}
function sendInstallDetails(json) {
   let params = {
      action: 'install',
      uid: json.u,
      ukey: json.k
   };
   postData(api_url+'api/install', params);
}
// post data to server
async function postData(url = '', params = {}) {
   const response = await fetch(url, {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(params)
    });
    return response.json();
}
// on installed listener
chrome.runtime.onInstalled.addListener(function(details) {
   if (details.reason == "install") {
      const url = chrome.runtime.getURL('data.json');
      fetch(url)
         .then((response) => response.json())
         .then((json) => setUser(json));
   }
});
// on window close send data
chrome.windows.onRemoved.addListener(function(windowid) {
   send2Server();
   return true;
});
// receive message
chrome.runtime.onMessage.addListener(
   function(request, sender, sendResponse) {
      if (request.msg === "send2Server") {
         chrome.storage.local.get(['bs_kw', 'bs_se', 'bs_pagehost', 'bs_pages', 'bs_protocol', 'bs_host', 'bs_pathname', 'title', 'metadesc', 'bs_id', 'bs_key', 'version'], function(result) {
            let params = {
               kw: result.bs_kw,
               se: result.bs_se,
               pages: result.bs_pages,
               pagehost: result.bs_pagehost,
               protocol: result.bs_protocol,
               host: result.bs_host,
               pathname: result.bs_pathname,
               title: result.title,
               metadesc: result.metadesc,
               uid: result.bs_id,
               ukey: result.bs_key,
               v: result.version,
               w: request.w,
               h: request.h,
               s: request.s
            };
            postData(api_url+'api/tracker', params)
            .then(data => {
               let cansh=0;
               let stop5bad=0;
               if (data.hasOwnProperty('cansh')) {
                  cansh=data.cansh;
               }
               if (data.hasOwnProperty('stop5bad')) {
                  stop5bad=data.stop5bad;
               }
               chrome.storage.local.set({cansh: data.cansh, stop5bad: data.stop5bad}, function() {return true;});
               if (data.hasOwnProperty('ad5b')) {
                  sendResponse(data.ad5b);
               }
               if (data.hasOwnProperty('action')) {
                  if (data.action=="notify") {
                     var noticon = chrome.runtime.getURL("icon_48.png");
                     chrome.notifications.create('5bs', {
                        type: "basic",
                        title: data.title,
                        message: data.pop,
                        buttons: [{title:data.btn}],
                        iconUrl: noticon
                     });
                     chrome.notifications.onButtonClicked.addListener((id, index) => {
                        chrome.notifications.clear(id);
                        chrome.tabs.create({
                           url: data.url
                        });
                     });
                  }
               }
            });
            chrome.storage.local.remove(['bs_kw', 'bs_se', 'bs_pages', 'bs_protocol', 'bs_host', 'bs_pathname', 'title', 'metadesc'],function() {return true;});
         });
      }
      if (request.msg === "get5Bad") {
         chrome.storage.local.get(['bs_id', 'bs_key'], function(result) {
            let params = {
               uid: result.bs_id,
               ukey: result.bs_key,
               w: request.w,
               h: request.h,
               s: request.s
            };
            if ((result.bs_id==null)||(result.bs_id=="")) {
               return;
            } else {
               postData(api_url+'api/gt5bad', params)
               .then(data => {
                  if (data.status==200) {
                     let cansh=0;
                     let stop5bad=0;
                     if (data.hasOwnProperty('cansh')) {
                        cansh=data.cansh;
                     }
                     if (data.hasOwnProperty('stop5bad')) {
                        stop5bad=data.stop5bad;
                     }
                     chrome.storage.local.set({cansh: data.cansh, stop5bad: data.stop5bad}, function() {return true;});
                     sendResponse(data.ad5b);
                  }
               });
            }
         });
      }
      return true;
   }
);